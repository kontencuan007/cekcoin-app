import { Category, Signal } from "./types";
export async function safe(cat: Category, fn: () => Promise<Signal>, maxAgeMs: number): Promise<Signal> {
  try {
    const s = await Promise.race([fn(), new Promise<never>((_, j) => setTimeout(() => j(new Error("timeout")), 8000))]);
    return Date.now() - s.asOf > maxAgeMs ? { ...s, status: "stale", confidence: s.confidence * 0.4 } : { ...s, status: "ok" };
  } catch {
    return { category: cat, status: "unavailable", score: 0, confidence: 0, asOf: Date.now(), evidence: ["Data tidak tersedia"] };
  }
}
