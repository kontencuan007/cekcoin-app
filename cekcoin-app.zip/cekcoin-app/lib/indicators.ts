export function ema(v: number[], p: number) {
  const k = 2 / (p + 1); const out: number[] = [];
  v.forEach((x, i) => out.push(i ? x * k + out[i - 1] * (1 - k) : x));
  return out;
}
export function rsi(v: number[], p = 14) {
  let g = 0, l = 0;
  for (let i = 1; i <= p; i++) { const d = v[i] - v[i - 1]; d >= 0 ? (g += d) : (l -= d); }
  g /= p; l /= p;
  for (let i = p + 1; i < v.length; i++) {
    const d = v[i] - v[i - 1];
    g = (g * (p - 1) + Math.max(d, 0)) / p; l = (l * (p - 1) + Math.max(-d, 0)) / p;
  }
  return l === 0 ? 100 : 100 - 100 / (1 + g / l);
}
