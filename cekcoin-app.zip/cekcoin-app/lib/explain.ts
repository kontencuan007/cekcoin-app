import Anthropic from "@anthropic-ai/sdk";
let client: Anthropic | null = null;
export async function explain(p: any) {
  if (!process.env.ANTHROPIC_API_KEY) throw new Error("no key");
  client ??= new Anthropic();
  const msg = await client.messages.create({
    model: "claude-sonnet-5-5", max_tokens: 900,
    system: `Kamu penjelas keputusan mesin analisis kripto. ATURAN KERAS:
- Arah (${p.decision.verdict}) dan semua angka sudah final. Dilarang mengubah/membalik arah atau mengarang angka.
- Hanya pakai fakta dari "evidence" dan level dari "setup". Kutip bukti spesifik.
- Jika decision.conflict=true, jelaskan sinyal mana yang bertentangan.
- Jangan menjanjikan profit. Bahasa Indonesia, ringkas.
Balas HANYA JSON: {"summary":string,"bull_case":string,"bear_case":string,"risks":string[]}`,
    messages: [{ role: "user", content: JSON.stringify(p) }],
  });
  const t = msg.content.map((b: any) => b.text ?? "").join("");
  const j = JSON.parse(t.replace(/```json|```/g, "").trim());
  return { summary: j.summary ?? "", bull_case: j.bull_case ?? "", bear_case: j.bear_case ?? "", risks: Array.isArray(j.risks) ? j.risks : [] };
}
export function templateNarrative(p: any) {
  return {
    summary: `${p.name}: ${p.decision.verdict}, keyakinan ${p.decision.conviction}%. ` +
      p.signals.filter((s: any) => s.status !== "unavailable").map((s: any) => `${s.category} ${s.score > 0.05 ? "mendukung naik" : s.score < -0.05 ? "menekan turun" : "netral"}`).join("; ") + ".",
    bull_case: "", bear_case: "", risks: p.signals.flatMap((s: any) => (s.status === "unavailable" ? [] : s.evidence)).slice(0, 4),
  };
}
