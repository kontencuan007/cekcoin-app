export type Category = "technical" | "fundamental" | "derivatives" | "onchain" | "macro" | "sentiment" | "social";
export type Signal = {
  category: Category; status: "ok" | "stale" | "unavailable";
  score: number; confidence: number; asOf: number; evidence: string[];
};
