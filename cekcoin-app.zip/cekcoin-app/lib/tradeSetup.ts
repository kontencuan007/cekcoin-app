import { Candle } from "./market";
export function atr(c: Candle[], p = 14) {
  const tr = (i: number) => Math.max(c[i].high - c[i].low, Math.abs(c[i].high - c[i - 1].close), Math.abs(c[i].low - c[i - 1].close));
  let a = 0; for (let i = 1; i <= p; i++) a += tr(i); a /= p;
  for (let i = p + 1; i < c.length; i++) a = (a * (p - 1) + tr(i)) / p;
  return a;
}
export function levels(c: Candle[], a: number) {
  const piv: number[] = [];
  for (let i = 3; i < c.length - 3; i++) {
    const w = c.slice(i - 3, i + 4);
    if (c[i].low === Math.min(...w.map((x) => x.low))) piv.push(c[i].low);
    if (c[i].high === Math.max(...w.map((x) => x.high))) piv.push(c[i].high);
  }
  piv.sort((x, y) => x - y);
  const out: { price: number; touches: number }[] = [];
  for (const p of piv) {
    const l = out[out.length - 1];
    if (l && p - l.price < 0.5 * a) { l.price = (l.price * l.touches + p) / (l.touches + 1); l.touches++; }
    else out.push({ price: p, touches: 1 });
  }
  return out.map((l) => ({ ...l, strength: l.touches >= 3 ? "Strong" : l.touches === 2 ? "Moderate" : "Weak" }));
}
export function tradeSetup(c: Candle[], side: "LONG" | "SHORT") {
  if (c.length < 40) return null;
  const price = c[c.length - 1].close, a = atr(c), lv = levels(c, a), long = side === "LONG", dir = long ? 1 : -1;
  const pool = lv.filter((l) => (long ? l.price < price : l.price > price) && l.touches >= 2)
    .sort((x, y) => (long ? y.price - x.price : x.price - y.price));
  const base = pool[0]?.price ?? price - dir * a;
  const zone = long ? [base, base + 0.3 * a] : [base - 0.3 * a, base];
  const entry = (zone[0] + zone[1]) / 2, sl = long ? zone[0] - 0.6 * a : zone[1] + 0.6 * a, risk = Math.abs(entry - sl);
  const tps = [1.5, 3, 5].map((rr) => { const p = entry + dir * rr * risk; return { rr, price: p, pct: (p / entry - 1) * 100 }; });
  return {
    side, price, atr: a, zone, sl, slPct: (risk / entry) * 100, tps,
    waitPullback: long ? price > zone[1] + 0.5 * a : price < zone[0] - 0.5 * a,
    invalidation: pool[1]?.price ?? sl - dir * a,
    levels: lv.filter((l) => Math.abs(l.price - price) < 8 * a),
  };
}
export function position(capital: number, riskPct: number, entry: number, sl: number, tps: number[]) {
  const riskUsd = (capital * riskPct) / 100, d = Math.abs(entry - sl) || 1e-12;
  const units = riskUsd / d, notional = units * entry;
  return { units, notional, loss: -riskUsd, profits: tps.map((t) => units * Math.abs(t - entry)),
    leverage: notional > capital && capital > 0 ? Math.ceil(notional / capital) : null };
}
