import { Signal } from "../types";
import { clamp } from "../util";
const CG = "https://api.coingecko.com/api/v3";
const H: Record<string, string> = process.env.COINGECKO_KEY ? { "x-cg-demo-api-key": process.env.COINGECKO_KEY } : {};
export async function resolveCoin(q: string) {
  const r = await fetch(`${CG}/search?query=${encodeURIComponent(q)}`, { headers: H, next: { revalidate: 3600 } }).then((r) => r.json());
  const hit = r.coins?.find((c: any) => c.symbol.toLowerCase() === q.toLowerCase()) ?? r.coins?.[0];
  if (!hit) throw new Error("Coin tidak ditemukan");
  return hit.id as string;
}
export async function coinInfo(id: string) {
  const r = await fetch(`${CG}/coins/${encodeURIComponent(id)}?localization=false&tickers=false&community_data=false&developer_data=false`,
    { headers: H, next: { revalidate: 180 } });
  if (!r.ok) throw new Error(r.status === 429 ? "CoinGecko sedang membatasi permintaan, coba lagi sebentar" : `CoinGecko ${r.status}`);
  const j = await r.json(), m = j.market_data;
  return {
    id, name: j.name as string, symbol: String(j.symbol).toUpperCase(), rank: j.market_cap_rank as number | null,
    image: j.image?.small as string, categories: ((j.categories ?? []) as string[]).filter(Boolean).slice(0, 3),
    price: m.current_price.usd as number, ath: m.ath.usd as number, athPct: m.ath_change_percentage.usd as number,
    mcap: m.market_cap.usd as number, fdv: (m.fully_diluted_valuation?.usd ?? null) as number | null,
    vol24h: m.total_volume.usd as number, votesUp: (j.sentiment_votes_up_percentage ?? null) as number | null,
  };
}
export type Info = Awaited<ReturnType<typeof coinInfo>>;
export async function fundamental(info: Info): Promise<Signal> {
  const ev: string[] = []; let score = 0; const r = info.rank ?? 999;
  score += r <= 10 ? 0.3 : r <= 100 ? 0.15 : -0.15;
  ev.push(`Rank #${r} — ${r <= 10 ? "Large-cap (risiko Rendah)" : r <= 100 ? "Mid-cap (risiko Sedang)" : "Small-cap (risiko Tinggi)"}`);
  if (info.fdv && info.mcap) {
    const x = info.fdv / info.mcap;
    score += x < 1.2 ? 0.15 : x > 3 ? -0.3 : x > 1.8 ? -0.15 : 0;
    ev.push(`FDV/MCap ${x.toFixed(2)}x${x < 1.2 ? " — risiko dilusi kecil" : x > 2 ? " — risiko dilusi besar" : ""}`);
  }
  const vm = info.vol24h / info.mcap;
  score += vm > 0.1 ? 0.15 : vm < 0.02 ? -0.2 : 0;
  ev.push(`Volume/MCap ${(vm * 100).toFixed(1)}%`);
  ev.push(`${info.athPct.toFixed(0)}% dari ATH`);
  score += info.athPct < -80 ? -0.1 : 0;
  return { category: "fundamental", status: "ok", score: clamp(score), confidence: 0.6, asOf: Date.now(), evidence: ev };
}
