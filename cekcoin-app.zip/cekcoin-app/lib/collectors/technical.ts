import { getCandles } from "../market";
import { ema, rsi } from "../indicators";
import { clamp } from "../util";
import { Signal } from "../types";
const TFS = ["15m", "1h", "4h", "1d"];
export async function technical(sym: string): Promise<Signal> {
  const per = await Promise.all(TFS.map(async (tf) => {
    const c = await getCandles(sym, tf), cl = c.map((x) => x.close), p = cl[cl.length - 1];
    const e20 = ema(cl, 20).at(-1)!, e50 = ema(cl, 50).at(-1)!, r = rsi(cl);
    const rs = r > 70 ? -0.4 : r < 30 ? 0.4 : ((r - 50) / 50) * 0.5;
    const rvol = c.at(-1)!.volume / (c.slice(-21, -1).reduce((a, x) => a + x.volume, 0) / 20);
    return { s: clamp(0.4 * (e20 > e50 ? 1 : -1) + 0.3 * (p > e20 ? 1 : -1) + rs), r, rvol, tf };
  }));
  const bull = per.filter((x) => x.s > 0.15).length, bear = per.filter((x) => x.s < -0.15).length;
  const h = per.find((x) => x.tf === "4h")!;
  return {
    category: "technical", status: "ok", confidence: 0.9, asOf: Date.now(),
    score: per.reduce((a, x) => a + x.s, 0) / per.length,
    evidence: [`${bull} timeframe bullish, ${bear} bearish dari ${TFS.length}`, `RSI14 4H ${h.r.toFixed(1)}, RVOL 4H ${h.rvol.toFixed(2)}x (spot Binance)`],
  };
}
