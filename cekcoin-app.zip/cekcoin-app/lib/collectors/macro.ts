import { Signal } from "../types";
import { clamp } from "../util";
export async function fng() {
  const j = await fetch("https://api.alternative.me/fng/", { next: { revalidate: 900 } }).then((r) => r.json());
  return { value: +j.data[0].value, label: j.data[0].value_classification as string, at: +j.data[0].timestamp * 1000 };
}
let st: { t: number; chg: number } | null = null;
async function stableChg() {
  if (st && Date.now() - st.t < 15 * 60_000) return st.chg;
  const j = await fetch("https://stablecoins.llama.fi/stablecoins?includePrices=false", { cache: "no-store" }).then((r) => r.json());
  const now = j.peggedAssets.reduce((a: number, s: any) => a + (s.circulating?.peggedUSD ?? 0), 0);
  const prev = j.peggedAssets.reduce((a: number, s: any) => a + (s.circulatingPrevWeek?.peggedUSD ?? 0), 0);
  const chg = prev ? (now / prev - 1) * 100 : 0; st = { t: Date.now(), chg }; return chg;
}
export async function macro(): Promise<Signal> {
  const [f, chg] = await Promise.all([fng(), stableChg().catch(() => null)]);
  const score = clamp((50 - f.value) / 120 + (chg ?? 0) / 2);
  const ev = [`Fear & Greed ${f.value} (${f.label})`];
  if (chg != null) ev.push(`Supply stablecoin ${chg >= 0 ? "+" : ""}${chg.toFixed(2)}% 7h`);
  return { category: "macro", status: "ok", score, confidence: 0.5, asOf: f.at, evidence: ev };
}
