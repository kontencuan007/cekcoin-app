import Parser from "rss-parser";
import { Signal } from "../types";
import { clamp } from "../util";
const FEEDS = [
  { src: "CoinDesk", url: "https://www.coindesk.com/arc/outboundfeeds/rss/" },
  { src: "Cointelegraph", url: "https://cointelegraph.com/rss" },
  { src: "Decrypt", url: "https://decrypt.co/feed" },
];
const parser = new Parser({ timeout: 6000 });
type Item = { src: string; title: string; link: string; t: number };
let cache: { t: number; items: Item[] } | null = null;
async function allNews(): Promise<Item[]> {
  if (cache && Date.now() - cache.t < 5 * 60_000) return cache.items;
  const res = await Promise.allSettled(FEEDS.map(async (f) => {
    const feed = await parser.parseURL(f.url);
    return feed.items.map((i) => ({ src: f.src, title: i.title ?? "", link: i.link ?? "", t: new Date(i.isoDate ?? i.pubDate ?? 0).getTime() }));
  }));
  const items = res.flatMap((r) => (r.status === "fulfilled" ? r.value : []));
  if (!items.length) throw new Error("semua feed gagal");
  cache = { t: Date.now(), items }; return items;
}
const esc = (s: string) => s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
const POS = ["surge","rally","soars","jumps","partnership","upgrade","inflow","approval","approved","adopt","record high","breakout","launch","listing","buyback"];
const NEG = ["hack","exploit","lawsuit","sues","outflow","delist","crash","plunge","drops","liquidat","scam","fraud","ban","investigation","rug","stolen","sell-off","selloff"];
export async function news(name: string, symbol: string, maxAgeH = 72) {
  const parts = [`\\b${esc(name)}\\b`, `\\$${esc(symbol)}\\b`]; if (symbol.length >= 4) parts.push(`\\b${esc(symbol)}\\b`);
  const re = new RegExp(parts.join("|"), "i"), since = Date.now() - maxAgeH * 3.6e6;
  const items = (await allNews()).filter((i) => i.t > since && re.test(i.title)).sort((a, b) => b.t - a.t).slice(0, 8)
    .map((i) => { const l = i.title.toLowerCase(); return { ...i, tone: POS.filter((w) => l.includes(w)).length - NEG.filter((w) => l.includes(w)).length }; });
  const signal: Signal = items.length === 0
    ? { category: "sentiment", status: "ok", score: 0, confidence: 0.1, asOf: Date.now(), evidence: [`Tidak ada berita yang menyebut ${name} dalam ${maxAgeH} jam`] }
    : { category: "sentiment", status: "ok", asOf: items[0].t, score: clamp(items.reduce((a, i) => a + Math.sign(i.tone), 0) / items.length),
        confidence: Math.min(0.5, 0.15 + items.length * 0.07),
        evidence: [`${items.length} berita dalam ${maxAgeH} jam`, ...items.slice(0, 2).map((i) => `${i.src}: ${i.title}`)] };
  return { signal, items };
}
