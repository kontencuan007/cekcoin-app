import { Signal } from "../types";
import { clamp } from "../util";
import type { Info } from "./fundamental";
export async function social(info: Info): Promise<Signal> {
  if (info.votesUp == null) throw new Error("tidak ada data vote");
  const v = info.votesUp;
  return { category: "social", status: "ok", score: clamp((v - 55) / 45) * (v > 85 ? 0.5 : 1), confidence: 0.3, asOf: Date.now(),
    evidence: [`Komunitas CoinGecko: ${v.toFixed(0)}% bullish${v > 85 ? " — euforia, hati-hati" : v < 40 ? " — pesimis" : ""}`] };
}
