import { Signal } from "../types";
import { clamp } from "../util";
let cache: { t: number; data: any[] } | null = null;
async function protocols() {
  if (cache && Date.now() - cache.t < 10 * 60_000) return cache.data;
  const data = await fetch("https://api.llama.fi/protocols", { cache: "no-store" }).then((r) => r.json());
  cache = { t: Date.now(), data }; return data as any[];
}
export async function onchain(geckoId: string): Promise<Signal> {
  const p = (await protocols()).find((x) => x.gecko_id === geckoId);
  if (!p) throw new Error("bukan token protokol DeFi");
  const d1 = p.change_1d ?? 0, d7 = p.change_7d ?? 0;
  return { category: "onchain", status: "ok", score: clamp(d7 / 30 + d1 / 60), confidence: 0.55, asOf: Date.now(),
    evidence: [`TVL $${(p.tvl / 1e6).toFixed(1)}M (${p.name})`, `TVL ${d1 >= 0 ? "+" : ""}${d1.toFixed(1)}% 24j, ${d7 >= 0 ? "+" : ""}${d7.toFixed(1)}% 7h`] };
}
