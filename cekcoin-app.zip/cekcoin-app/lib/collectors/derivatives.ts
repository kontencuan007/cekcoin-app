import { Signal } from "../types";
import { getCandles } from "../market";
import { clamp } from "../util";
const F = "https://fapi.binance.com";
export async function derivatives(sym: string): Promise<Signal> {
  const get = (p: string) => fetch(F + p, { next: { revalidate: 60 } }).then((r) => {
    if (!r.ok) throw new Error(`futures ${r.status}`); return r.json();
  });
  const [prem, oiHist, ls, candles] = await Promise.all([
    get(`/fapi/v1/premiumIndex?symbol=${sym}USDT`),
    get(`/futures/data/openInterestHist?symbol=${sym}USDT&period=4h&limit=12`),
    get(`/futures/data/globalLongShortAccountRatio?symbol=${sym}USDT&period=4h&limit=1`),
    getCandles(sym, "4h"),
  ]);
  const funding = +prem.lastFundingRate * 100;
  const oiChg = (+oiHist.at(-1).sumOpenInterestValue / +oiHist[0].sumOpenInterestValue - 1) * 100;
  const px = candles.slice(-12), pxChg = (px.at(-1)!.close / px[0].close - 1) * 100, lsr = +ls[0].longShortRatio;
  let score = 0; const ev: string[] = [];
  if (Math.abs(oiChg) > 3 && Math.abs(pxChg) > 1) {
    if (oiChg > 0 && pxChg > 0) { score += 0.4; ev.push(`Futures: OI naik ${oiChg.toFixed(1)}% + harga naik ${pxChg.toFixed(1)}% — tren didukung posisi baru`); }
    else if (oiChg > 0) { score -= 0.4; ev.push(`Futures: OI naik ${oiChg.toFixed(1)}% + harga turun ${Math.abs(pxChg).toFixed(1)}% — short baru masuk`); }
    else if (pxChg > 0) { score += 0.1; ev.push(`Futures: harga naik tapi OI turun ${Math.abs(oiChg).toFixed(1)}% — short covering, kurang kuat`); }
    else { score -= 0.1; ev.push("Futures: harga & OI sama-sama turun — posisi ditutup"); }
  } else ev.push(`Futures: OI ${oiChg >= 0 ? "+" : ""}${oiChg.toFixed(1)}% (48 jam), harga ${pxChg >= 0 ? "+" : ""}${pxChg.toFixed(1)}%`);
  score += funding > 0.08 ? -0.35 : funding > 0.04 ? -0.15 : funding < -0.04 ? 0.3 : funding < -0.015 ? 0.15 : 0;
  ev.push(`Funding ${funding.toFixed(4)}% / 8j${funding > 0.04 ? " — long terlalu ramai" : funding < -0.015 ? " — short ramai" : ""}`);
  score += lsr > 2 ? -0.15 : lsr < 0.8 ? 0.15 : 0;
  ev.push(`Rasio akun long/short ${lsr.toFixed(2)}`);
  return { category: "derivatives", status: "ok", score: clamp(score), confidence: 0.75, asOf: +oiHist.at(-1).timestamp, evidence: ev };
}
