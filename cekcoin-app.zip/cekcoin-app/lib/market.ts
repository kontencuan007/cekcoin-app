export type Candle = { time: number; open: number; high: number; low: number; close: number; volume: number; takerBuy: number };
const BASE = "https://data-api.binance.vision";
export async function getCandles(sym: string, tf = "4h", closedOnly = true): Promise<Candle[]> {
  const res = await fetch(`${BASE}/api/v3/klines?symbol=${sym}USDT&interval=${tf}&limit=300`, { next: { revalidate: 30 } });
  if (!res.ok) throw new Error(`binance ${res.status}`);
  const rows: any[] = await res.json();
  return rows.filter((r) => !closedOnly || r[6] < Date.now()).map((r) => ({
    time: Math.floor(r[0] / 1000), open: +r[1], high: +r[2], low: +r[3], close: +r[4], volume: +r[5], takerBuy: +r[9],
  }));
}
