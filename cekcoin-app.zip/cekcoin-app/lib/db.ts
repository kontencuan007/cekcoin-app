import { createClient, SupabaseClient } from "@supabase/supabase-js";
let c: SupabaseClient | null = null;
export function getDb() {
  if (!process.env.SUPABASE_URL || !process.env.SUPABASE_SERVICE_KEY) return null;
  return (c ??= createClient(process.env.SUPABASE_URL, process.env.SUPABASE_SERVICE_KEY));
}
