export const fmt = (n: number) => {
  if (!isFinite(n)) return "-";
  if (Math.abs(n) >= 1000) return n.toLocaleString("en-US", { maximumFractionDigits: 2 });
  if (Math.abs(n) >= 1) return n.toFixed(2);
  const d = Math.min(12, 3 - Math.floor(Math.log10(Math.abs(n) || 1)));
  return n.toFixed(d);
};
export const usd = (n: number) => "$" + fmt(n);
export const pct = (n: number) => `${n >= 0 ? "+" : ""}${n.toFixed(2)}%`;
