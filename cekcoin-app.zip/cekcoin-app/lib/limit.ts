const hits = new Map<string, number[]>();
// In-memory: berlaku per instance serverless. Untuk produksi ketat, ganti ke Upstash.
export function allow(ip: string, max = 10, windowMs = 3600_000) {
  const now = Date.now(), arr = (hits.get(ip) ?? []).filter((t) => now - t < windowMs);
  if (arr.length >= max) { hits.set(ip, arr); return false; }
  arr.push(now); hits.set(ip, arr); return true;
}
