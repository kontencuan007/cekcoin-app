import { Category, Signal } from "./types";
export const WEIGHTS: Record<Category, number> = {
  technical: 0.32, derivatives: 0.22, fundamental: 0.10, onchain: 0.08, macro: 0.10, sentiment: 0.10, social: 0.08,
};
export function decide(signals: Signal[]) {
  let num = 0, den = 0;
  for (const s of signals) { const w = WEIGHTS[s.category] * s.confidence; num += w * s.score; den += w; }
  const composite = den ? num / den : 0;
  const dir = Math.sign(composite) || 1;
  let against = 0, total = 0; const conflictWith: Category[] = [];
  for (const s of signals) {
    const w = WEIGHTS[s.category] * s.confidence; total += w;
    if (w > 0 && Math.abs(s.score) > 0.2 && Math.sign(s.score) !== dir) { against += w; conflictWith.push(s.category); }
  }
  const ratio = total ? against / total : 0;
  const coverage = signals.filter((s) => s.status !== "unavailable").reduce((a, s) => a + WEIGHTS[s.category], 0);
  const verdict = composite > 0.2 ? "BELI" : composite < -0.2 ? "JUAL" : "TAHAN";
  const base = Math.min(1, Math.abs(composite) * 1.5);
  const conviction = Math.round(base * (1 - ratio * 0.7) * (0.5 + 0.5 * coverage) * 100);
  return {
    verdict, conviction, composite: +composite.toFixed(3), gauge: Math.round(composite * 100),
    conflict: ratio > 0.2, conflictWith, coverage: +coverage.toFixed(2),
    missing: signals.filter((s) => s.status === "unavailable").map((s) => s.category),
  };
}
