export const clamp = (x: number) => Math.max(-1, Math.min(1, x));
