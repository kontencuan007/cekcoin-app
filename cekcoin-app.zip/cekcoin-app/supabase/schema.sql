create table if not exists signal_log (
  id bigserial primary key, symbol text not null, tf text not null, verdict text not null,
  conviction int not null, composite numeric not null, price numeric not null, atr_pct numeric,
  signals jsonb not null, created_at timestamptz default now(),
  evaluated_at timestamptz, outcome_price numeric, ret_pct numeric, hit boolean
);
create index if not exists signal_log_sym on signal_log (symbol, created_at desc);
create index if not exists signal_log_todo on signal_log (evaluated_at) where evaluated_at is null;

create table if not exists derivs_snapshot (
  id bigserial primary key, symbol text not null, oi numeric, funding numeric, mark numeric, created_at timestamptz default now()
);
create index if not exists derivs_sym on derivs_snapshot (symbol, created_at desc);

create table if not exists analysis_cache (
  key text primary key, payload jsonb not null, created_at timestamptz default now()
);

create or replace view accuracy_30d as
select symbol, count(*) as n, round(avg(hit::int) * 100) as pct
from signal_log where hit is not null and created_at > now() - interval '30 days' group by symbol;

alter table signal_log enable row level security;
alter table derivs_snapshot enable row level security;
alter table analysis_cache enable row level security;
