const ago = (t: number) => { const h = Math.round((Date.now() - t) / 3.6e6); return h < 1 ? "baru saja" : h < 24 ? `${h} jam lalu` : `${Math.round(h / 24)} hari lalu`; };
export default function NewsList({ items }: { items: any[] }) {
  return (
    <section className="card">
      <h3>Katalis &amp; Berita <small className="muted">ringkasan otomatis — verifikasi sebelum aksi</small></h3>
      {items.length === 0 && <p className="muted">Belum ada berita terbaru dari sumber yang dipantau.</p>}
      {items.map((n) => (
        <a key={n.link} href={n.link} target="_blank" rel="noopener noreferrer" className="news">
          <div className="row"><b>{n.source}</b><span className="muted small" style={{ marginLeft: "auto" }}>{ago(n.at)}</span></div>
          <p>{n.title}</p>
        </a>
      ))}
    </section>
  );
}
