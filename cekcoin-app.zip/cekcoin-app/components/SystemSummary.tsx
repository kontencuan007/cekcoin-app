const NAMES: Record<string, string> = {
  technical: "Teknikal (multi-TF)", fundamental: "Fundamental", derivatives: "Derivatif (funding/OI)",
  onchain: "On-chain", macro: "Makro (dominance/F&G)", sentiment: "Sentimen/berita", social: "Sosial",
};
const label = (s: number) => `${s > 0.05 ? "mendukung NAIK" : s < -0.05 ? "menekan TURUN" : "netral"} · ${Math.abs(s) > 0.6 ? "kuat" : Math.abs(s) > 0.3 ? "sedang" : "ringan"}`;
export default function SystemSummary({ decision, signals }: any) {
  const meaning = ({ BELI: "sistem melihat peluang naik — pertimbangkan entry sesuai zona.", JUAL: "sistem melihat tekanan turun — hindari entry baru.",
    TAHAN: "sistem belum ada arah yang jelas — tahan dulu posisi yang ada." } as any)[decision.verdict];
  const level = decision.conviction >= 60 ? "tinggi" : decision.conviction >= 35 ? "sedang" : "rendah";
  return (
    <section className="card">
      <h3>Kesimpulan Sistem <small className="muted">dihitung dari data — bukan tebakan AI</small></h3>
      <div className="gaugeRow">
        <span className="badge">{decision.verdict}</span>
        <div className="gauge"><div className="track" /><i style={{ left: `${(decision.gauge + 100) / 2}%` }} />
          <div className="ends"><span>−100 bearish</span><span>bullish +100</span></div></div>
      </div>
      <p>Artinya: sistem <b className="accent">{meaning}</b></p>
      <p className="muted small">Tingkat keyakinan <b>{decision.conviction}%</b> ({level}).{decision.conflict && " Beberapa sinyal saling bertentangan, jadi keyakinannya sengaja diturunkan."}</p>
      {decision.conflict && <div className="warn">⚠ <b>Sinyal bertentangan:</b> {decision.conflictWith.map((c: string) => NAMES[c]).join(", ")} bergerak berlawanan dengan arah keseluruhan.</div>}
      {decision.missing?.length > 0 && <p className="muted small">Data tidak tersedia: {decision.missing.map((c: string) => NAMES[c]).join(", ")}</p>}
      <small className="muted">APA KATA TIAP SINYAL</small>
      {signals.map((s: any) => (
        <div className="sig" key={s.category}>
          <span>{NAMES[s.category]}</span>
          <div className="bar"><div className="mid" />
            {s.status !== "unavailable" && <div className={s.score >= 0 ? "pos" : "neg"} style={{ width: `${Math.min(50, Math.abs(s.score) * 50)}%`, [s.score >= 0 ? "left" : "right"]: "50%" }} />}
          </div>
          <span className={s.status === "unavailable" ? "muted" : s.score >= 0 ? "up" : "down"}>
            {s.status === "stale" && <span className="chip warnchip">basi</span>} {s.status === "unavailable" ? "tidak tersedia" : label(s.score)}
          </span>
        </div>
      ))}
      <details><summary>Lihat detail angka</summary>
        {signals.map((s: any) => (<div key={s.category}><b>{NAMES[s.category]}</b> <span className="muted small">(skor {s.score.toFixed(2)}, keyakinan {Math.round(s.confidence * 100)}%)</span>
          <ul>{s.evidence.map((e: string) => <li key={e}>{e}</li>)}</ul></div>))}
      </details>
    </section>
  );
}
