"use client";
import { useState } from "react";
import { fmt, usd, pct } from "@/lib/format";
import { position } from "@/lib/tradeSetup";
export default function TradeSetup({ setup, hold }: { setup: any; hold: boolean }) {
  const [cap, setCap] = useState(1000), [risk, setRisk] = useState(1);
  const entry = (setup.zone[0] + setup.zone[1]) / 2;
  const p = position(cap, risk, entry, setup.sl, setup.tps.map((t: any) => t.price));
  return (
    <section className="card">
      <h3>Trade Setup <span className={`chip ${setup.side === "LONG" ? "up" : "down"}`}>{setup.side}</span></h3>
      {hold && <div className="warn">Sistem sedang TAHAN. Setup di bawah hanya referensi level, bukan sinyal masuk.</div>}
      {setup.waitPullback && <div className="warn">⏳ Harga masih jauh dari zona entry. Lebih baik <b>TUNGGU</b> harga mendekati {usd(setup.zone[0])}–{usd(setup.zone[1])}; entry sekarang R:R-nya jelek.</div>}
      <div className="grid3">
        <div className="mini"><small>Zona Entry</small><b className="accent">{usd(setup.zone[0])}–{usd(setup.zone[1])}</b></div>
        <div className="mini"><small>Stop Loss</small><b className="down">{usd(setup.sl)}</b><small>{setup.slPct.toFixed(2)}%</small></div>
        <div className="mini"><small>Risk : Reward</small><b className="up">1 : {setup.tps[setup.tps.length - 1].rr}</b></div>
      </div>
      {setup.tps.map((t: any, i: number) => (<div className="tp" key={i}><b>TP{i + 1}</b><span>{usd(t.price)}</span><span className="up">{pct(t.pct)} · RR {t.rr}</span></div>))}
      <div className="warn danger">Ide batal kalau harga menutup {setup.side === "LONG" ? "di bawah" : "di atas"} {fmt(setup.invalidation)}.</div>
      <div className="calc">
        <h4>Kalkulator Posisi &amp; Risiko</h4>
        <div className="grid2">
          <label>Modal (USD)<input type="number" min={0} value={cap} onChange={(e) => setCap(+e.target.value)} /></label>
          <label>Risiko / trade (%)<input type="number" min={0} step={0.1} value={risk} onChange={(e) => setRisk(+e.target.value)} /></label>
        </div>
        <dl>
          <dt>Ukuran posisi</dt><dd>{Math.round(p.units).toLocaleString("id-ID")} unit</dd>
          <dt>Nilai posisi</dt><dd>${p.notional.toFixed(2)}</dd>
          <dt>Potensi RUGI ke SL</dt><dd className="down">−${Math.abs(p.loss).toFixed(2)}</dd>
          {p.profits.map((x, i) => [<dt key={`a${i}`}>Untung di TP{i + 1}</dt>, <dd key={`b${i}`} className="up">+${x.toFixed(2)}</dd>])}
          <dt>Saran leverage</dt><dd>{p.leverage ? `${p.leverage}x` : "tanpa leverage"}</dd>
        </dl>
        <small className="muted">Estimasi; belum termasuk fee/slippage. ⚠ Bukan saran finansial.</small>
      </div>
    </section>
  );
}
