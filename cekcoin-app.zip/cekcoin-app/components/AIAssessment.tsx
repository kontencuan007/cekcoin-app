export default function AIAssessment({ ex, aiDown, coin, decision }: any) {
  return (
    <section className="card">
      <h3>Penilaian AI <small className="muted">menjelaskan keputusan sistem — bukan menebak arah</small></h3>
      <p><b>{coin.name} ({coin.symbol}) — {decision.verdict}</b></p>
      <p>{ex.summary}</p>
      {ex.bull_case && (<div className="grid2">
        <div className="scen up"><b>Skenario Bullish</b><p>{ex.bull_case}</p></div>
        <div className="scen down"><b>Skenario Bearish</b><p>{ex.bear_case}</p></div></div>)}
      {ex.risks?.length > 0 && (<><b>Risiko &amp; yang diwaspadai</b><ul>{ex.risks.map((r: string) => <li key={r}>{r}</li>)}</ul></>)}
      {aiDown && <small className="muted">Narasi ringkas (AI penuh sedang tak tersedia) — arah &amp; level tetap valid (dihitung mesin sistem).</small>}
      <p className="muted small">⚠ Bukan saran finansial.</p>
    </section>
  );
}
