"use client";
import { useEffect, useRef } from "react";
export default function Chart({ candles, setup }: any) {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    let dispose = () => {};
    (async () => {
      const { createChart, LineStyle } = await import("lightweight-charts");
      if (!ref.current) return;
      const ch = createChart(ref.current, { height: 380, layout: { background: { color: "#0e141b" }, textColor: "#8b98a5" },
        grid: { vertLines: { visible: false }, horzLines: { color: "#161b22" } }, rightPriceScale: { borderColor: "#1b2733" }, timeScale: { borderColor: "#1b2733" } });
      const s = ch.addCandlestickSeries({ upColor: "#22c55e", downColor: "#ef4444", borderVisible: false, wickUpColor: "#22c55e", wickDownColor: "#ef4444" });
      s.setData(candles);
      const line = (price: number, color: string, title: string, style: number = LineStyle.Solid) => s.createPriceLine({ price, color, title, lineStyle: style, lineWidth: 1, axisLabelVisible: true });
      if (setup) {
        setup.levels.forEach((l: any) => line(l.price, l.price < setup.price ? "#22c55e" : "#ef4444", `${l.price < setup.price ? "Support" : "Resistance"} ${l.strength} (${l.touches}x)`));
        line(setup.sl, "#ef4444", "Stop Loss", LineStyle.Dashed);
        setup.tps.forEach((t: any, i: number) => line(t.price, "#22c55e", `TP${i + 1}`, LineStyle.Dashed));
        setup.zone.forEach((z: number) => line(z, "#38bdf8", "Zona Entry", LineStyle.Dotted));
      }
      ch.timeScale().fitContent();
      const onResize = () => ref.current && ch.applyOptions({ width: ref.current.clientWidth });
      window.addEventListener("resize", onResize); onResize();
      dispose = () => { window.removeEventListener("resize", onResize); ch.remove(); };
    })();
    return () => dispose();
  }, [candles, setup]);
  return <div ref={ref} style={{ width: "100%" }} />;
}
