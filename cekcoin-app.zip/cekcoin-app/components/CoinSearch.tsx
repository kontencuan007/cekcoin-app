"use client";
import { useEffect, useState } from "react";
export default function CoinSearch({ onPick }: { onPick: (c: any) => void }) {
  const [q, setQ] = useState(""), [list, setList] = useState<any[]>([]), [picked, setPicked] = useState(false);
  useEffect(() => {
    if (picked) return;
    const t = setTimeout(async () => {
      if (q.length < 2) return setList([]);
      try { setList(await fetch(`/api/search?q=${encodeURIComponent(q)}`).then((r) => r.json())); } catch { setList([]); }
    }, 300);
    return () => clearTimeout(t);
  }, [q, picked]);
  return (
    <div className="search">
      <input value={q} onChange={(e) => { setPicked(false); setQ(e.target.value); }} placeholder="Cari coin apa saja — Bitcoin, HYPE, memecoin…" />
      {list.length > 0 && (
        <ul>
          {list.map((c) => (
            <li key={c.id} onClick={() => { setPicked(true); onPick(c); setQ(`${c.name} (${c.symbol})`); setList([]); }}>
              <img src={c.thumb} width={20} height={20} alt="" /> {c.name} <b>{c.symbol}</b>
              {c.rank && <span>#{c.rank}</span>}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
