import { usd } from "@/lib/format";
export default function CoinHeader({ coin, decision, tf, accuracy }: any) {
  const tone = decision.verdict === "BELI" ? "up" : decision.verdict === "JUAL" ? "down" : "hold";
  return (
    <section className="card">
      <div className="row">
        <img src={coin.image} width={48} height={48} alt="" style={{ borderRadius: 24 }} />
        <div>
          <h2>{coin.name} <small>{coin.symbol}</small> {coin.rank && <span className="chip">#{coin.rank}</span>}</h2>
          <p className="muted small">{coin.categories.join(" · ")}</p>
        </div>
        <div className="price">{usd(coin.price)}</div>
      </div>
      <div className={`reco ${tone}`}>
        <div>
          <small>REKOMENDASI · {tf.toUpperCase()}</small>
          <h1>{decision.verdict}</h1>
          <span className="chip">{accuracy ? `Akurasi 30hr: ${accuracy.pct}% · dari ${accuracy.n} sinyal` : "Akurasi: data belum cukup"}</span>
        </div>
        <div className="conv"><b>{decision.conviction}%</b><small>keyakinan</small></div>
      </div>
      <div className="stats">
        <div><small>ATH</small><b className="down">{usd(coin.ath)}</b><small>{coin.athPct.toFixed(2)}%</small></div>
        <div><small>Market Cap</small><b>${(coin.mcap / 1e9).toFixed(2)}B</b></div>
        <div><small>Volume 24j</small><b>${(coin.vol24h / 1e6).toFixed(2)}M</b></div>
        <div><small>Fear &amp; Greed</small><b>{coin.fng?.value ?? "-"}</b><small>{coin.fng?.label}</small></div>
      </div>
    </section>
  );
}
