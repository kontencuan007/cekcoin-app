# CekCoin

Satu keputusan (BELI / TAHAN / JUAL) + alasannya, dihitung mesin dari 7 kategori sinyal. AI hanya menjelaskan, tidak menentukan arah.

## Jalankan lokal
```bash
npm install
cp .env.example .env.local   # sudah berisi test key hCaptcha untuk dev
npm run dev                  # http://localhost:3000
```
Tanpa `ANTHROPIC_API_KEY` narasi memakai template. Tanpa Supabase, cache dan rekam akurasi nonaktif; aplikasi tetap jalan.

## Deploy
1. Supabase: jalankan `supabase/schema.sql` di SQL Editor.
2. Vercel: import repo ini, isi env dari `.env.example` (pakai key hCaptcha asli), atur Function Region ke Singapore (sin1) agar tidak diblokir Binance.
3. GitHub Actions: tambahkan secret `APP_URL` dan `CRON_SECRET` (sama dengan di Vercel). Jalankan workflow `cekcoin-cron` manual sekali untuk tes.

## Catatan
- Bobot di `lib/engine.ts` adalah tebakan awal; setel ulang dari `signal_log` setelah data terkumpul.
- Rate limit di `lib/limit.ts` bersifat per instance; ganti ke Upstash untuk produksi.
- Bukan saran finansial.
