export const dynamic = "force-dynamic";
export async function GET(req: Request) {
  const q = new URL(req.url).searchParams.get("q") ?? "";
  if (q.length < 2) return Response.json([]);
  const h: Record<string, string> = process.env.COINGECKO_KEY ? { "x-cg-demo-api-key": process.env.COINGECKO_KEY } : {};
  const r = await fetch(`https://api.coingecko.com/api/v3/search?query=${encodeURIComponent(q)}`, { headers: h, next: { revalidate: 300 } });
  if (!r.ok) return Response.json([]);
  const j = await r.json();
  return Response.json((j.coins ?? []).slice(0, 6).map((c: any) => ({ id: c.id, name: c.name, symbol: String(c.symbol).toUpperCase(), rank: c.market_cap_rank, thumb: c.thumb })));
}
