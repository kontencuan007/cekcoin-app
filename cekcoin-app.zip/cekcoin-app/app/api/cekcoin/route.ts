import { NextResponse } from "next/server";
import { getCandles } from "@/lib/market";
import { safe } from "@/lib/safe";
import { decide } from "@/lib/engine";
import { tradeSetup } from "@/lib/tradeSetup";
import { explain, templateNarrative } from "@/lib/explain";
import { getDb } from "@/lib/db";
import { allow } from "@/lib/limit";
import { technical } from "@/lib/collectors/technical";
import { derivatives } from "@/lib/collectors/derivatives";
import { coinInfo, fundamental, resolveCoin } from "@/lib/collectors/fundamental";
import { onchain } from "@/lib/collectors/onchain";
import { macro, fng } from "@/lib/collectors/macro";
import { news } from "@/lib/collectors/news";
import { social } from "@/lib/collectors/social";

export const preferredRegion = "sin1";
export const maxDuration = 30;
export const dynamic = "force-dynamic";
const TFS = ["15m", "1h", "4h", "1d", "1w"];

async function captchaOk(token: string) {
  if (!process.env.HCAPTCHA_SECRET) return true; // dev tanpa captcha
  if (!token) return false;
  const v = await fetch("https://api.hcaptcha.com/siteverify", {
    method: "POST", headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({ secret: process.env.HCAPTCHA_SECRET, response: token }),
  }).then((r) => r.json()).catch(() => ({ success: false }));
  return !!v.success;
}

export async function POST(req: Request) {
  try {
    const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() ?? "anon";
    if (!allow(ip)) return NextResponse.json({ error: "Terlalu banyak permintaan, coba lagi nanti" }, { status: 429 });
    const body = await req.json();
    const tf = TFS.includes(body.timeframe) ? body.timeframe : "4h";
    if (!(await captchaOk(body.captcha))) return NextResponse.json({ error: "Verifikasi captcha gagal" }, { status: 400 });
    if (!body.geckoId && !body.symbol) return NextResponse.json({ error: "Pilih coin dulu" }, { status: 400 });

    const id: string = body.geckoId || (await resolveCoin(String(body.symbol)));
    const db = getDb(), key = `${id}:${tf}`;
    if (db) {
      const { data: hit } = await db.from("analysis_cache").select("payload").eq("key", key)
        .gt("created_at", new Date(Date.now() - 5 * 60_000).toISOString()).maybeSingle();
      if (hit) return NextResponse.json({ ...hit.payload, cached: true });
    }

    const info = await coinInfo(id);
    const s = info.symbol.replace(/[^A-Z0-9]/g, "");
    const [newsRes, candles, fg] = await Promise.all([
      news(info.name, info.symbol).catch(() => null),
      getCandles(s, tf, false).catch(() => null),
      fng().catch(() => null),
    ]);
    const signals = await Promise.all([
      safe("technical", () => technical(s), 5 * 60_000),
      safe("derivatives", () => derivatives(s), 10 * 60_000),
      safe("fundamental", () => fundamental(info), 30 * 60_000),
      safe("onchain", () => onchain(id), 3600_000),
      safe("macro", () => macro(), 24 * 3600_000),
      safe("sentiment", async () => { if (!newsRes) throw new Error("feed"); return newsRes.signal; }, 72 * 3600_000),
      safe("social", () => social(info), 24 * 3600_000),
    ]);
    const decision = decide(signals);
    const setup = candles && candles.length > 40 ? tradeSetup(candles.slice(0, -1), decision.verdict === "JUAL" ? "SHORT" : "LONG") : null;

    let explanation: any, aiDown = false;
    const payload = { name: info.name, symbol: info.symbol, timeframe: tf, decision,
      signals: signals.map((x) => ({ category: x.category, status: x.status, score: +x.score.toFixed(2), evidence: x.evidence })),
      setup: setup && { side: setup.side, zone: setup.zone, sl: setup.sl, tps: setup.tps.map((t) => t.price), invalidation: setup.invalidation } };
    try { explanation = await explain(payload); } catch { aiDown = true; explanation = templateNarrative(payload); }

    let accuracy: any = null;
    if (db) {
      const { data: acc } = await db.from("accuracy_30d").select("*").eq("symbol", s).maybeSingle();
      accuracy = acc && acc.n >= 30 ? { pct: acc.pct, n: acc.n } : null;
      db.from("signal_log").insert({ symbol: s, tf, verdict: decision.verdict, conviction: decision.conviction, composite: decision.composite,
        price: info.price, atr_pct: setup ? setup.atr / info.price : null, signals }).then(() => {}, () => {});
    }

    const result = {
      coin: { ...info, fng: fg },
      decision, signals, accuracy, setup,
      candles: candles ? candles.slice(-200).map(({ time, open, high, low, close }) => ({ time, open, high, low, close })) : null,
      explanation, aiDown,
      news: (newsRes?.items ?? []).map((i) => ({ source: i.src, title: i.title, link: i.link, at: i.t })),
    };
    if (db) db.from("analysis_cache").upsert({ key, payload: result, created_at: new Date().toISOString() }).then(() => {}, () => {});
    return NextResponse.json(result);
  } catch (e: any) {
    return NextResponse.json({ error: e?.message ?? "Terjadi kesalahan" }, { status: 500 });
  }
}
