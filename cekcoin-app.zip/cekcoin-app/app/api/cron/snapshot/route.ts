import { getDb } from "@/lib/db";
export const preferredRegion = "sin1";
export const maxDuration = 60;
export const dynamic = "force-dynamic";
const COINS = ["BTC","ETH","BNB","SOL","XRP","DOGE","ADA","AVAX","TRX","LINK","DOT","LTC","SUI","PEPE","SHIB","NEAR","UNI","APT","ARB","OP","INJ","TON","HYPE","AAVE","ATOM"];
export async function GET(req: Request) {
  if (!process.env.CRON_SECRET || req.headers.get("authorization") !== `Bearer ${process.env.CRON_SECRET}`) return new Response("unauthorized", { status: 401 });
  const db = getDb(); if (!db) return Response.json({ error: "db belum dikonfigurasi" }, { status: 503 });
  const rows = (await Promise.all(COINS.map(async (c) => {
    try {
      const [oi, f] = await Promise.all([
        fetch(`https://fapi.binance.com/fapi/v1/openInterest?symbol=${c}USDT`).then((r) => r.json()),
        fetch(`https://fapi.binance.com/fapi/v1/premiumIndex?symbol=${c}USDT`).then((r) => r.json()),
      ]);
      if (!oi.openInterest) return null;
      return { symbol: c, oi: +oi.openInterest, funding: +f.lastFundingRate, mark: +f.markPrice };
    } catch { return null; }
  }))).filter(Boolean);
  if (rows.length) await db.from("derivs_snapshot").insert(rows as any[]);
  return Response.json({ inserted: rows.length });
}
