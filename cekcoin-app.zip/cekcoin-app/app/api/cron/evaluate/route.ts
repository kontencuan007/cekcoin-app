import { getDb } from "@/lib/db";
export const preferredRegion = "sin1";
export const maxDuration = 60;
export const dynamic = "force-dynamic";
const HORIZON_H: Record<string, number> = { "15m": 1.5, "1h": 6, "4h": 24, "1d": 144, "1w": 336 };
export async function GET(req: Request) {
  if (!process.env.CRON_SECRET || req.headers.get("authorization") !== `Bearer ${process.env.CRON_SECRET}`) return new Response("unauthorized", { status: 401 });
  const db = getDb(); if (!db) return Response.json({ error: "db belum dikonfigurasi" }, { status: 503 });
  const { data: rows } = await db.from("signal_log").select("*").is("evaluated_at", null).limit(200);
  let done = 0;
  for (const r of rows ?? []) {
    const ageH = (Date.now() - new Date(r.created_at).getTime()) / 3.6e6;
    if (ageH < (HORIZON_H[r.tf] ?? 24)) continue;
    const t = await fetch(`https://data-api.binance.vision/api/v3/ticker/price?symbol=${r.symbol}USDT`).then((x) => x.json()).catch(() => null);
    if (!t?.price) continue;
    const ret = (+t.price / r.price - 1) * 100, band = (r.atr_pct ?? 0.03) * 100 * 1.5;
    const hit = r.verdict === "BELI" ? ret > 0 : r.verdict === "JUAL" ? ret < 0 : Math.abs(ret) < band;
    await db.from("signal_log").update({ evaluated_at: new Date().toISOString(), outcome_price: +t.price, ret_pct: ret, hit }).eq("id", r.id);
    done++;
  }
  return Response.json({ evaluated: done });
}
