"use client";
import { useRef, useState } from "react";
import HCaptcha from "@hcaptcha/react-hcaptcha";
import CoinSearch from "@/components/CoinSearch";
import CoinHeader from "@/components/CoinHeader";
import SystemSummary from "@/components/SystemSummary";
import TradeSetup from "@/components/TradeSetup";
import AIAssessment from "@/components/AIAssessment";
import NewsList from "@/components/NewsList";
import Chart from "@/components/Chart";
const TFS = ["15m", "1h", "4h", "1d", "1w"];
const SITEKEY = process.env.NEXT_PUBLIC_HCAPTCHA_SITEKEY;
export default function Home() {
  const [coin, setCoin] = useState<any>(null), [tf, setTf] = useState("4h");
  const [token, setToken] = useState(SITEKEY ? "" : "dev"), [res, setRes] = useState<any>(null);
  const [loading, setLoading] = useState(false), [err, setErr] = useState("");
  const cap = useRef<HCaptcha>(null);
  async function run() {
    setLoading(true); setErr(""); setRes(null);
    try {
      const r = await fetch("/api/cekcoin", { method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ symbol: coin.symbol, geckoId: coin.id, timeframe: tf, captcha: token }) });
      const j = await r.json();
      if (!r.ok) throw new Error(j.error ?? "Gagal menganalisis");
      setRes(j);
    } catch (e: any) { setErr(e.message); }
    finally { setLoading(false); if (SITEKEY) { cap.current?.resetCaptcha(); setToken(""); } }
  }
  return (
    <main className="wrap">
      <h1 className="logo">CekCoin</h1>
      <p className="tag">⚡ Satu keputusan yang jelas + alasannya — ditimbang dari <b>7 kategori sinyal</b></p>
      <section className="card">
        <p>Pilih coin &amp; timeframe untuk mulai:</p>
        <CoinSearch onPick={setCoin} />
        <div className="tfs">Timeframe:{TFS.map((t) => <button key={t} className={t === tf ? "on" : ""} onClick={() => setTf(t)}>{t.toUpperCase()}</button>)}</div>
        {SITEKEY && <HCaptcha ref={cap} sitekey={SITEKEY} onVerify={setToken} onExpire={() => setToken("")} theme="dark" />}
        <button className="cta" disabled={!coin || !token || loading} onClick={run}>{loading ? "Menganalisis…" : "⚡ Mulai Analisa"}</button>
        {err && <p className="down">{err}</p>}
      </section>
      {res && (<>
        <CoinHeader coin={res.coin} decision={res.decision} tf={tf} accuracy={res.accuracy} />
        <SystemSummary decision={res.decision} signals={res.signals} />
        {res.candles && <section className="card"><Chart candles={res.candles} setup={res.setup} /></section>}
        {res.setup && <TradeSetup setup={res.setup} hold={res.decision.verdict === "TAHAN"} />}
        <AIAssessment ex={res.explanation} aiDown={res.aiDown} coin={res.coin} decision={res.decision} />
        <NewsList items={res.news} />
        <button className="cta" onClick={() => { setRes(null); window.scrollTo({ top: 0 }); }}>↻ Analisa Lagi</button>
        <p className="muted small center">Data: Binance · CoinGecko · DefiLlama · Alternative.me. Bukan saran finansial.</p>
      </>)}
    </main>
  );
}
