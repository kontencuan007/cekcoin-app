import "./globals.css";
export const metadata = { title: "CekCoin", description: "Satu keputusan yang jelas + alasannya, ditimbang dari 7 kategori sinyal." };
export const viewport = { width: "device-width", initialScale: 1 };
export default function RootLayout({ children }: { children: React.ReactNode }) {
  return <html lang="id"><body>{children}</body></html>;
}
